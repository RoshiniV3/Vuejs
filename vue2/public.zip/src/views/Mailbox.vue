<template>
  <div>
    <h2>Mailbox</h2>
    <p>This is the Mailbox page.</p>
  </div>
</template>

<script>
export default {
  name: 'Mailbox'
}
</script>
