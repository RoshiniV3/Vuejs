<template>
  <div>
    <h2>Calendar</h2>
    <p>This is the Calendar page.</p>
  </div>
</template>

<script>
export default {
  name: 'Calendar'
}
</script>
